# نظام مهراني — خطوات النشر على Firebase عبر GitHub

## الملفات
- `public/index.html` ← منيو الطلبات (الزبون)
- `public/cashier.html` ← لوحة الكاشير
- `firebase.json` ← إعدادات الاستضافة
- `.firebaserc` ← ربط المشروع (mahrani-94697)
- `.github/workflows/deploy.yml` ← النشر التلقائي
- `firestore.rules` ← قواعد الأمان

---

## أولاً: قواعد Firestore (مهم — مرة وحدة)
1. Firebase Console → Firestore Database → تبويب **Rules**
2. الصق محتوى ملف `firestore.rules`
3. اضغط **Publish**

(هذا يخلي الطلبات تشتغل بدون توقف بعد ٣٠ يوم)

---

## ثانياً: رفع الملفات على GitHub
1. أنشئ مستودع جديد (New repository) باسم `mahrani`
2. ارفع كل ملفات هذا المجلد فيه (بنفس الترتيب: مجلد public، وملفات firebase.json و .firebaserc، ومجلد .github)
3. تأكد إن الفرع الأساسي اسمه **main**

---

## ثالثاً: ربط Firebase بـ GitHub (مفتاح النشر)
عشان GitHub Actions يقدر ينشر على Firebase، يحتاج "مفتاح حساب الخدمة":

1. افتح: https://console.firebase.google.com/project/mahrani-94697/settings/serviceaccounts/adminsdk
2. اضغط **Generate new private key** → بينزّل ملف JSON
3. افتح ملف JSON وانسخ محتواه كامل
4. في GitHub: المستودع → **Settings → Secrets and variables → Actions → New repository secret**
5. الاسم: `FIREBASE_SERVICE_ACCOUNT`
6. القيمة: الصق محتوى ملف JSON كامل → **Add secret**

---

## رابعاً: التشغيل
- أي رفع (push) على فرع main ينشر تلقائياً
- الروابط بعد النشر:
  - المنيو: `https://mahrani-94697.web.app/`
  - الكاشير: `https://mahrani-94697.web.app/cashier.html`

---

## روابط الطاولات (الباركود)
كل طاولة لها رابط بهذا الشكل:
```
https://mahrani-94697.web.app/?t=رقم_الطاولة&b=الفرع
```
أمثلة:
- طاولة 5 في أبها:  `https://mahrani-94697.web.app/?t=5&b=abha`
- طاولة 12 في خميس مشيط:  `https://mahrani-94697.web.app/?t=12&b=khamis`

(نظام توليد الباركود لكل الطاولات نبنيه في الخطوة الجاية)
